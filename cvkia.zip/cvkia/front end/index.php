
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cv_saskia</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<div class="header"> 
<div class="gambar"> <img src="kia.jpg.jpg" alt="ini gambar saya">
</div>
<h1>saskia</h1>
<h3>girlfriend haechan</h3>
</div>

<div class="main">
    <div class="left">
       <h2>Informasi identitas</h2>
       <p><strong> Nama </strong>Saskia Putri Naya</p>
       <p><strong> Alamat </strong>eka jaya</p>
       <p><strong> no_hp </strong>088286731901</p>
       <p><strong> Skill </strong>fasih bahasa inggris</p>
       <h2>Pendidikan</h2>
       <p><strong> Sekolah Dasar </strong>Unggul Sakti</p>
       <p><strong> Sekolah Lanjutan Tingkat Pertama </strong>Mts al-hidayah</p>
       <p><strong> Sekolah Menengah Kejuruan </strong>Smkn6 kota jambi</p>
    </div>
    <div class="right">
        <h2>Pekerjaan</h2>
        <p><strong> dikorea </strong> artis </p>
        <h2>Kepribadian</h2>
        <p><strong> sifat </strong> saya </p>
        <li> baik hati </li>
        <li> tidak suka marah marah </li>
        <li> soft spoken </li>
</div>
</div>
</div>
</body>
</html>