<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM cv_saskia");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM cv_saskia WHERE
     nama like '%$Pencarian%' or
   kelas like '%$Pencarian%'or
    umur like '%$Pencarian%' or
     no_hp like '%$Pencarian%' or
      tanggal_lahir like '%$Pencarian%' or
       pengalaman like '%$Pencarian%' or 
       Skill like '%$Pencarian%' or 
          Pendidikan like '%$Pencarian%' or 
           Hobi like '%$Pencarian%'" ;
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM cv_saskia');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="logo">
    </div>
    <div id="header-title">
<a href="index.php">saskia</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="index.php">Data</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="login.php">Keluar</a></li>
        </ul>
    </div>
    <div class="konten">
<h1>SASKIA PUTRI NAYA</h1> 
<p>SASKIA PUTRI NAYA adalah salah satu siswi SMK NEGERI 6 KOTA JAMBI</p>

</div>
</body>
<body>
       <h1>Hak Cipta 2025 . Pengembangan Perangkat Lunak dan Gim</h1>
</div>

</html>