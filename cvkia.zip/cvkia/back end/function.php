<?php
$database= mysqli_connect('localhost','root','','saskia');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $umur = $_POST ["umur"];
    $kelas = $_POST ["kelas"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $Skill = $_POST ["Skill"];
    $Pendidikan = $_POST ["Pendidikan"];
    $Hobi = $_POST ["Hobi"];
    $tambah = "INSERT INTO cv_saskia VALUE
    ('','$nama','$umur','$kelas','$no_hp','$tanggal_lahir','$pengalaman','$Skill','$Pendidikan','$Hobi')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM cv_saskia where no=$hapus");
    return mysqli_affected_rows($database);
}


?>