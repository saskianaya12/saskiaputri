<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
$database= mysqli_connect('localhost','root','','saskia');//menampilkan Nama database
$hapus = $_GET ["no"]; //fungsi hapus
$data= mysqli_query ($database,"SELECT * FROM cv_saskia WHERE no=$hapus");

if(isset ($_POST["tombol"])){
    $no = $_POST ["no"];
    $nama = $_POST ["nama"];
    $kelas = $_POST ["kelas"];
    $umur = $_POST ["umur"];
    $no_hp = $_POST ["no_hp"];
    $tanggal_lahir = $_POST ["tanggal_lahir"];
    $pengalaman = $_POST ["pengalaman"];
    $Skill = $_POST ["Skill"];
    $Pendidikan = $_POST ["Pendidikan"];
    $Hobi = $_POST ["Hobi"];


    $edit = "UPDATE cv_saskia SET
    nama = '$nama',
    kelas = '$kelas',
    umur = '$umur',
    no_hp= '$no_hp',
    tanggal_lahir = '$tanggal_lahir',
    pengalaman = '$pengalaman'
    Skill = '$Skill'
    Pendidikan = '$Pendidikan'
    Hobi = '$Hobi'
    WHERE no=$hapus";

    mysqli_query($database,$edit);
    
    //cek apabila data sudah tersimpan
    if (mysqli_affected_rows($database)>0){
        echo "<script>
        alert ('Data Berhasil Diubah');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Diubah');
        document.location.href='index.php';
        </script>";
    }
}

?>
<!DOCTYPE html>
<head>
    <title>Edit Data</title>
</head>
<body>

<?php
    while($cari= mysqli_fetch_assoc ($data)):
    ?>
    <h2>Edit Data</h2>
    <form method="POST">
    <input type="hidden" name="no" value="<?= $cari ['no'];?>">
<ul>
<li><label >Nama</label></li>
<li><input type="text" name="nama" value="<?= $cari ['nama'];?>"></li>
    <li><label >Kelas</label></li>
    <li><input type="text" name="kelas" value="<?= $cari ['kelas'];?>"></li>
    <li><label >Umur</label></li>
    <li><input type="text" name="umur" value="<?= $cari ["umur"];?>"></li>
    <li><label >No HP</label></li>
    <li><input type="text" name="no_hp" value="<?php echo $cari ['no_hp'];?>"></li>
    <li><label >Tanggal Lahir</label></li>
    <li><input type="text" name="tanggal_lahir" value="<?php echo $cari ['tanggal_lahir'];?>"></li>
    <li><label >Pengalaman</label></li>
    <li><input type="text" name="pengalaman" value="<?php echo $cari ['pengalaman'];?>"></li>
    <li><label >Skill</label></li>
    <li><input type="text" name="pengalaman" value="<?php echo $cari ['Skill'];?>"></li>
    <li><label >Pendidikan</label></li>
    <li><input type="text" name="pengalaman" value="<?php echo $cari ['Pendidikan'];?>"></li>
    <li><label >Hobi</label></li>
    <li><input type="text" name="pengalaman" value="<?php echo $cari ['Hobi'];?>"></li>
    <li><button type="submit" name="tombol">Perbaharuin data</button></li>
</ul>
<?php
    endwhile;
    ?>
    </form>
</body>
</html>